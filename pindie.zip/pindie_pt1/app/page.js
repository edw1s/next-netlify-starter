import Image from "next/image";
import styles from "./page.module.css";


import { Banner } from "./components/Banner/Banner";
import { Promo } from "./components/Promo/Promo";
import { CardList } from "./components/CardsList/CardsList"
import { getGamesByCategory } from "@/app/data/data-utils";

export default function Home() {
    const popularGames = getGamesByCategory("popular");
    const newGames = getGamesByCategory("new");

    return(
        <main>
            <Banner />
            <CardList id="new" title="Новинки" data={newGames} />
            <CardList id="popular" title="Популярные" data={popularGames}/>
            <Promo />
        </main>
    )
}