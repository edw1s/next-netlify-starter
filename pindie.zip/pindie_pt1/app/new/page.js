import { CardList } from "@/app/components/CardsList/CardsList";
import { getGamesByCategory } from "@/app/data/data-utils";

export default function New() {
    const newGames = getGamesByCategory("new")
    return (
        <main className="main-inner">
            <CardList id="new" title="Новинки" data={ newGames } />
        </main>
    )
}