import { CardList } from "@/app/components/CardsList/CardsList";
import { getGamesByCategory } from "@/app/data/data-utils";

export default function Tds() {
    const tdsGames = getGamesByCategory("tds")
    return (
        <main className="main-inner">
            <CardList id="tds" title="TDS" data={tdsGames} />
        </main>
    )
}