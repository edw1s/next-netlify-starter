import { CardList } from "@/app/components/CardsList/CardsList";
import { getGamesByCategory } from "@/app/data/data-utils";

export default function Shooters() {
    const shooterGames = getGamesByCategory("shooters")
    return (
        <main className="main-inner">
            <CardList id="shooter" title="Шутеры" data={shooterGames} />
        </main>
    )
}