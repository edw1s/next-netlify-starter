"use client"
import {useEffect, useState} from "react";
import Style from "./Promo.module.css"

export const Promo = () => {
    const [codeIsVisible, setCodeIsVisible] = useState(false)

    const handleButtonClick = () => {
        !codeIsVisible && setCodeIsVisible(true)
    }

    useEffect(() => {
        let timeout;
        if (codeIsVisible) {
            timeout=setTimeout(() => {
                setCodeIsVisible(false);
            }, 5000)
        }
        return () => {
            clearTimeout(timeout)
        }
    }, [codeIsVisible]);

    return (
        <section className={Style.promo}>
            <div className="promo__description-block">
                <h2 className={Style.promo__title}>Твой промо-код</h2>
                <p className={Style.promo__description}>Скидка на все курсы Яндекс Практикума для пользователей нашего сайта!</p>
                <button className={`button ${Style["promo__button"]}`} onClick={handleButtonClick}>
                    {codeIsVisible ? (
                        <span className={`${Style["promo-code"]}`}>WEBTEEN10</span>
                    ) : (
                        "Получить код"
                    )}
                </button>
            </div>
            <img src="/images/promo-illustration.svg" alt="Собака" className={Style.promo__image}/>
        </section>
    )
}