import Style from "./Card.module.css"

export const Card = ({
    image,
    title,
    description,
    developer,
    users
}) => {
    return (
        <article className={Style.card}>
            <img
                src={image}
                alt=""
                className={Style.card__image}
            />
            <div className={Style["card__content-block"]}>
                <h3 className={Style.card__title}>{title}</h3>
                <p className={Style.card__description}>{description}</p>
                <div className={Style["card__info-container"]}>
                    <p className={Style.card__author}>
                        Автор: <span className={Style.card__accent}>{developer}</span>
                    </p>
                    <p className={Style.card__votes}>
                        Голосов на сайте: <span className={Style.card__accent}>{users.length}</span>
                    </p>
                </div>
            </div>
        </article>
    )
}