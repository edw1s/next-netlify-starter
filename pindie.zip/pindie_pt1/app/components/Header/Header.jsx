"use client"

import Style from "./Header.module.css"
import {useState} from 'react'
import {Overlay} from "@/app/components/Overlay/Overlay";
import {Popup} from "@/app/components/Popup/Popup";
import {AuthForm} from "@/app/components/AuthForm/AuthForm";
import Link from "next/link";
import {usePathname} from "next/navigation";


export const Header = () => {
    const [popupIsOpened, setPopupIsOpened] = useState(false);

    const openPopup = () => {
        setPopupIsOpened(true)
    }
    const closePopup = () => {
        setPopupIsOpened(false)
    }
    return (
        <header className={Style.header}>
            <Link className={Style.logo} href="/">
                <img className={Style.logo__image} src="/images/logo.svg" alt="Логотип Pindie"/>
            </Link>
            <nav className={Style.menu}>
                <ul className={Style.menu__list}>
                    <li className={Style.menu__item}>
                        <Link
                            href="/new"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/new" ? Style["menu__link_active"] : ""
                            }`}
                        >Новинки</Link>
                    </li>
                    <li className={Style.menu__item}>
                        <Link
                            href="/popular"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/popular" ? Style["menu__link_active"] : ""
                            }`}
                        >Популярные</Link>
                    </li>
                    <li className={Style.menu__item}>
                        <Link
                            href="/shooters"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/shooters" ? Style["menu__link_active"] : ""
                            }`}
                        >Шутеры</Link>
                    </li>
                    <li className={Style.menu__item}>
                        <Link
                            href="/runners"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/runners" ? Style["menu__link_active"] : ""
                            }`}
                        >Ранеры</Link>
                    </li>
                    <li className={Style.menu__item}>
                        <Link
                            href="/pixel-games"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/pixel-games" ? Style["menu__link_active"] : ""
                            }`}
                        >Пиксельные</Link>
                    </li>
                    <li className={Style.menu__item}>
                        <Link
                            href="/tds"
                            className={`${Style["menu__link"]} ${
                                usePathname() === "/tds" ? Style["menu__link_active"] : ""
                            }`}
                        >TDS</Link>
                    </li>
                </ul>
                <div className={Style.auth}>
                    <button className={Style.auth__button} onClick={openPopup}>Войти</button>
                </div>
            </nav>
            <Overlay popupIsOpened={popupIsOpened} closePopup={closePopup}/>
            <Popup popupIsOpened={popupIsOpened} closePopup={closePopup}>
                <AuthForm />
            </Popup>
        </header>
    )
}