import Style from "./CardList.module.css"
import {NewCardsFragment} from "./NewCardsFragment";

export const NewCardsList = () => {
    return (
        <section className={Style["list-section"]}>
            <h2 className={Style["list-section__title"]} id="new">
                Новинки
            </h2>
            <ul className={Style["cards-list"]}>
                <NewCardsFragment/>
            </ul>
        </section>
    )
}