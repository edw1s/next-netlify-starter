import Style from "./Footer.module.css"
import Link from "next/link";

export const Footer = () => {
    return (
        <footer className={Style.footer}>
            <Link href="/" className={Style.footer__logo}>
        <span className={Style["footer__logo-name"]}>pindie</span
        ><span className="footer__logo-copy">, XXI век</span>
            </Link>
            <ul className={Style["social-list"]}>
                <li className="social-list__item">
                    <a href="" className={`${Style.button} ${Style["social-list__link"]}`}>YT</a>
                </li>
                <li className="social-list__item">
                    <a href="" className={`${Style.button} ${Style["social-list__link"]}`}>ВК</a>
                </li>
                <li className="social-list__item">
                    <a href="" className={`${Style.button} ${Style["social-list__link"]}`}>TG</a>
                </li>
            </ul>
        </footer>
    )
}