import { CardList } from "@/app/components/CardsList/CardsList";
import { getGamesByCategory } from "@/app/data/data-utils";

export default function Pixel() {
    const pixelGames = getGamesByCategory("pixel")
    return (
        <main className="main-inner">
            <CardList id="pixel" title="Пиксельные" data={pixelGames} />
        </main>
    )
}