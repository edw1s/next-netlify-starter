import { CardList } from "@/app/components/CardsList/CardsList";
import { getGamesByCategory } from "@/app/data/data-utils";

export default function Popular() {
    const popularGames = getGamesByCategory("popular")
    return (
        <main className="main-inner">
            <CardList id="popular" title="Популярное" data={ popularGames } />
        </main>
    )
}